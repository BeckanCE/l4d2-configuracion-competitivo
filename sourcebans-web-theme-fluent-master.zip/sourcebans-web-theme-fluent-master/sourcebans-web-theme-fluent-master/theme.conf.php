<?php
// Set the name of this theme here
define('theme_name', "SourceBans++ Fluent Design Theme Edition [PHP 8.1]");

// Set the author of this theme here
define('theme_author', "aXenDev + .Rushaway + Hackmastr");

// Set the version of the theme here
define('theme_version', "1.8.0 Git 173");

// Set the link of the theme here
define('theme_link', "https://github.com/Rushaway/sourcebans-web-theme-fluent/");

// Set the screenshot filename for your theme (must be inside your theme folder)
// Must be:  250px wide  X 170px High
define('theme_screenshot', "screenshot.jpg");

<?php
function HelpIcon($title, $text)
{
    return '<img border="0" align="absbottom" src="images/admin/help.png" class="tip" title="' .  $title . ' :: ' .  $text . '">';
}
